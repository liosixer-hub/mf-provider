import React from 'react';
import './ProviderComponent.css';
declare const Provider: React.FC;
export default Provider;
